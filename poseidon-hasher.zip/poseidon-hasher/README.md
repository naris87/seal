# Poseidon Hasher (Web3 Simple Project)

Ini adalah proyek Web3 paling sederhana yang menggunakan Poseidon hash.

## Cara Pakai
1. Pastikan kamu punya `Rust` dan `Cargo`
2. Jalankan dengan:
```
cargo run
```

## Apa yang Dilakukan?
Mengubah input angka `"123456"` menjadi hash menggunakan Poseidon sponge (dipakai di dunia ZK).
