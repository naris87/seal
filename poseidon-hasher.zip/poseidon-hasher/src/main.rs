use ark_bn254::Fr;
use ark_sponge::{poseidon::PoseidonSponge, CryptographicSponge};
use ark_std::str::FromStr;

fn main() {
    let input = "123456"; // Kamu bisa ganti ini
    let fr_input = Fr::from_str(input).unwrap();

    let mut sponge = PoseidonSponge::new();
    sponge.absorb(&[fr_input]);
    let hash = sponge.squeeze_field_elements::<Fr>(1);

    println!("Input  : {}", input);
    println!("Hashed : {:?}", hash[0]);
}
